# UNIVERSAL SOCCORSO ODV — prototipo app

Web app responsive / PWA in italiano, progettata per essere provata anche da telefono Android.

## Funzioni presenti
- Richiesta di trasporto con dati di contatto, indirizzi, data/orario, mobilità e note.
- Salvataggio locale nel browser/dispositivo.
- Agenda con ricerca, filtro per stato e aggiornamento stato.
- Preparazione di un messaggio WhatsApp al numero dell'associazione.
- Esportazione CSV.
- Elenco mezzi (Opel 7+1, Doblò 5+1, Berlingo 3+1) e autisti Bravo 1–6.
- Manifest e service worker per installazione PWA quando pubblicata via HTTPS.

## Come provarla
Aprire `index.html` in un browser per la prova base. Per installazione PWA e modalità offline, pubblicare la cartella su un hosting HTTPS e poi aprirla in Chrome Android: menu ⋮ → “Installa app” / “Aggiungi a schermata Home”.

## Limiti importanti
Questo è un prototipo funzionante lato dispositivo, non ancora una piattaforma multiutente. I dati vengono salvati nel browser del singolo dispositivo; non esiste ancora un database condiviso, autenticazione, sincronizzazione fra autisti/ufficio, notifiche push o protezione server dei dati. Non inserire dati sanitari sensibili reali finché non sono stati implementati backend, controllo accessi, informativa privacy e misure GDPR. Il marchio grafico US è un segnaposto, da sostituire con il logo ufficiale.

## Prossimo passo per una versione operativa
Collegare un backend sicuro (ad es. Supabase o un servizio equivalente), creare ruoli distinti per amministrazione/autista/cliente, regole di accesso per i dati e notifiche. Testare con dati fittizi prima dell'uso reale.
